class DataManager{

  DataManager(){
    print("kush");
  }


}