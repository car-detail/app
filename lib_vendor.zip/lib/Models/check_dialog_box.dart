class CheckDialogBox{
  String title;
  String id;
  String id2;
  bool ischeck = false;
  CheckDialogBox(this.title, this.id, {this.id2 = ""});
}