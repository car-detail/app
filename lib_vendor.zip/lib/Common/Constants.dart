class Constants{

  static double textsise14 = 14;


  static String navid = "navid";
  static String roleType = "roleType";
  static String rupee = "₹";
}